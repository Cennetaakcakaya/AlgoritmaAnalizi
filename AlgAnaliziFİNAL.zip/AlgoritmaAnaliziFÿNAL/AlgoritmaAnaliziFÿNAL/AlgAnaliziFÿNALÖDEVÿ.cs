﻿using AlgoritmaAnaliziFİNAL;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Bir sınıf seçin (Dijkstra, Kruskal, Prim):");
        string choice = Console.ReadLine();

        switch (choice)
        {
            case "Dijkstra":
            
                Dijkstra.DijkstraCalistir();
                break;
            case "Kruskal":
                Kruskal.KruskalCalistir();
                break;
            case "Prim":
                Prim.PrimCalistir();
                break;
            default:
                Console.WriteLine("Geçersiz seçim.");
                break;
        }
    }
}