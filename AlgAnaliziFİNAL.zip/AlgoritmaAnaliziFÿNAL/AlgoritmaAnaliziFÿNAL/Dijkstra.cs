﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmaAnaliziFİNAL
{
    internal class Dijkstra
    {
       
        // Düğüm sayısı
        static int V = 9;

        // En kısa mesafeyi bulmak için yardımcı metod oluşturdum
        static int EnKisaMesafe(int[] mesafe, bool[] kisaYolSeti)
        {
            // bu method mesafe ve kısayolSeti dizilerini alır 
            // henuz işlenmemiş düğümler arasında en küçük mesafeye sahip düğümü bulur

            // baslangıcta min degeri mümkün olan en yüksek degere ayarlarız
            // mini maxvalue ye esitledim çünkü başlangıçta hiçbir düğümün mesafesi bu değerden daha küçük değildir
            // minIndeks -1 olarak ayarlanır çünkü başlangıçta geçerli bir minimum indeks bulunmamaktadır. -1 değeri, geçerli bir düğüm indeksi olmadığını belirtir.


            int min = int.MaxValue, minIndeks = -1;

            for (int v = 0; v < V; v++)
                if (kisaYolSeti[v] == false && mesafe[v] <= min)
                // her düğümün (v) henüz işlenip işlenmediğini (kisaYolSeti[v] == false) anlarız bu sayede
                // mesafesinin (mesafe[v]) şu ana kadar bulunan minimum mesafeden (min) daha küçük veya eşit olup olmadığını kontrol ederiz
                {
                    //Eğer bu koşullar sağlanıyorsa, min değeri bu düğümün mesafesi olarak güncellenir
                    //ve minIndeks bu düğümün indeksine ayarlanır.

                    min = mesafe[v];
                    minIndeks = v;
                }
                // minIndeks değeri en küçük mesafeye sahip düğümün indeksini tutar.

            return minIndeks;
            //En kısa mesafeye sahip düğümün indeksini döndürür.

            

        }

        // Dijkstra algoritmasını uygulayan metod
        static void DijkstraAlgoritmasi(int[,] grafik, int kaynak)
        {
            int[] mesafe = new int[V]; //kaynaktan diğer dugumlere olan en kısa mesafeyi tutan dizi
            bool[] kisaYolSeti = new bool[V]; // kısaYolSeti dizisi düğümlerin işlenip işlenmediğini takip eder
            //DijkstraAlgoritmasi metodu, grafik matrisini (şehirler arası mesafeleri tutan 2D dizi)
            //ve kaynak düğümünü (başlangıç noktası) alır



            // başlangıç mesafelerini sonsuz olarak ayarlar ve kisaYolSeti[] dizisini false yapar
            for (int i = 0; i < V; i++)
            {
                //döngü, mesafe dizisinin tüm elemanlarını başlangıçta sonsuz (int.MaxValue) olarak ayarlar
                mesafe[i] = int.MaxValue;
                kisaYolSeti[i] = false;
                //kisaYolSeti dizisini tüm düğümler için false yapar,
                //yani hiçbir düğüm başlangıçta işlenmiş olarak işaretlenmez.
                //işlendikçe true olacaktır
            }

            // kaynağın kendisine olan mesafesi 0 aldım çünkü bir düğümün kendisine olan mesafesi yoktur
            mesafe[kaynak] = 0;

            // buradaki amacımız tüm dugumleri işlemek 
            // grafikteki kenar kadar çalısır
            for (int sayac = 0; sayac < V - 1; sayac++)
            {
                // en kısa mesafeye sahip dugumu secer asagıdaki satır 
                // bunun için yukarda tanımladıgım en kısa mesafe fonksiyonunu cagırır
                int u = EnKisaMesafe(mesafe, kisaYolSeti);
                // henuz islenmemişler arasında en kısa mesafeyi bulur
                // bu dugum u değişkenine atanır

                // secildikçe dugumlerı true yaparım ki işlenmiş olarak gorunurler
                kisaYolSeti[u] = true;
                // degeri true yaparaktan artık işlenmiş hale getiririz

                // seçilen düğüm u'nun komşularının mesafelerini günceller.
                for (int v = 0; v < V; v++)
                // for sayesinde tüm düğümleri kontrol eder
                    if (!kisaYolSeti[v] && grafik[u, v] != 0 && mesafe[u] != int.MaxValue && mesafe[u] + grafik[u, v] < mesafe[v])
                        //!kisaYolSeti[v] bu demek oluyorki dugum henuz işlenmemiş olmalı
                        //grafik[u, v] != 0: u ve v düğümleri arasında bir kenar (yol) olmalı
                        //yani mesafe 0 olmamlıdır ki bir yol bulunsun
                        //mesafe[u] != int.MaxValue:  bu demek oluyorki mesafe sonsuz olmamalı ulasılabilir deger olmali
                        //mesafe[u] + grafik[u, v] < mesafe[v] bu demektir ki u düğümü üzerinden  v düğümüne  gitmek mevcut bilinen yoldan kısa olmalı
                        mesafe[v] = mesafe[u] + grafik[u, v];
                //egerki tum bu kosullar saglanıyorsa mesafe[v] güncellenir 
                //yeni mesafe u düğümünün mesafesi ve u ile v arasındaki mesafenin toplamı olur
            }

            // Sonuçları yazdır
            CozumYazdir(mesafe);
        }

        // En kısa yolları yazdıran metod
        static void CozumYazdir(int[] mesafe)
        {
            Console.WriteLine("Düğüm\tKaynaktan Mesafe");
            //tek tek tüm düğümleri alır ve mesafelerini yazdırır
            for (int i = 0; i < V; i++)
                Console.WriteLine(i + "\t\t" + mesafe[i]);
        }

         internal   static void DijkstraCalistir()
        {
            // Şehirler arası mesafeler grafiği
            int[,] grafik = new int[,] {
            { 0, 4, 0, 0, 0, 0, 0, 8, 0 },
            { 4, 0, 8, 0, 0, 0, 0, 11, 0 },
            { 0, 8, 0, 7, 0, 4, 0, 0, 2 },
            { 0, 0, 7, 0, 9, 14, 0, 0, 0 },
            { 0, 0, 0, 9, 0, 10, 0, 0, 0 },
            { 0, 0, 4, 14, 10, 0, 2, 0, 0 },
            { 0, 0, 0, 0, 0, 2, 0, 1, 6 },
            { 8, 11, 0, 0, 0, 0, 1, 0, 7 },
            { 0, 0, 2, 0, 0, 0, 6, 7, 0 }
        };

            // Kaynak şehir 
            int kaynak = 0;

            // Dijkstra algoritmasını çalıştır
            DijkstraAlgoritmasi(grafik, kaynak);
        }
    }

}

