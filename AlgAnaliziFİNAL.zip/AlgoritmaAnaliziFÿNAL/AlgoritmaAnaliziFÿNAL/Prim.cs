﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmaAnaliziFİNAL
{
    internal class Prim
    {
        internal static void PrimCalistir()
        {
            int[,] graph = new int[,] { { 0, 2, 0, 6, 0 },
                                     { 2, 0, 3, 8, 5 },
                                     { 0, 3, 0, 0, 7 },
                                     { 6, 8, 0, 0, 9 },
                                     { 0, 5, 7, 9, 0 } };

            PrimAlgorithm prim = new PrimAlgorithm();

            // Minimum ağacı oluştur
            prim.PrimMST(graph);
        }

        class PrimAlgorithm
        {
            private const int V = 5; // Grafın düğüm sayısı

            // Yardımcı fonksiyon minimum key değerini bulur
            private int MinKey(int[] key, bool[] mstSet)
            {
                int min = int.MaxValue, minIndex = -1;

                for (int v = 0; v < V; v++)
                {
                    if (mstSet[v] == false && key[v] < min)
                    {
                        min = key[v];
                        minIndex = v;
                    }
                }

                return minIndex;
            }

            // Oluşturulan minimum ağacı ekrana yazdırmak için yardımcı fonksiyon
            private void PrintMST(int[] parent, int[,] graph)
            {
                Console.WriteLine("Edge \tWeight");
                for (int i = 1; i < V; i++)
                {
                    Console.WriteLine(parent[i] + " - " + i + "\t" + graph[i, parent[i]]);
                }
            }

            // Minimum spanning tree oluşturan fonksiyon
            public void PrimMST(int[,] graph)
            {
                // Oluşturulan minimum ağacın kenarlarını depolamak için dizi
                int[] parent = new int[V];

                // Minimum key değerlerini içeren dizi
                int[] key = new int[V];

                // Minimum ağacın içinde mi yoksa dışında mı olduğunu gösteren dizi
                bool[] mstSet = new bool[V];

                // Key değerlerini sonsuz olarak ayarla ve hepsini minimum ağaç dışında yap
                for (int i = 0; i < V; i++)
                {
                    key[i] = int.MaxValue;
                    mstSet[i] = false;
                }

                // İlk düğümü seç ve key değerini 0 olarak ayarla
                key[0] = 0;
                parent[0] = -1; // Minimum ağaçta root düğüm

                // Minimum ağacı oluştur
                for (int count = 0; count < V - 1; count++)
                {
                    // Minimum key değerine sahip düğümü al ve minimum ağaç içine ekle
                    int u = MinKey(key, mstSet);

                    // Seçilen düğümü minimum ağaç içine al
                    mstSet[u] = true;

                    // Seçilen düğümün komşularını güncelle
                    for (int v = 0; v < V; v++)
                    {
                        // Graph[v, u] != 0, u-V arasında bir kenar var ve v minimum ağaç içinde değilse ve key[v] güncellenmeliyse
                        if (graph[u, v] != 0 && mstSet[v] == false && graph[u, v] < key[v])
                        {
                            parent[v] = u;
                            key[v] = graph[u, v];
                        }
                    }
                }

                // Oluşturulan minimum ağacı ekrana yazdır
                PrintMST(parent, graph);
            }

           
        }
    }
}
