﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AlgoritmaAnaliziFİNAL
{
    internal class Kruskal
    {
        

        class Kenar : IComparable<Kenar>
        {
            //Kenar sınıfı, bir graf kenarını temsil eder.
            //IComparable<Kenar> arayüzü,
            //kenarları ağırlıklarına göre karşılaştırabilmek için uygulanır.
             public int Kaynak { get; set; }
             public int Hedef { get; set; }
             public int Agirlik { get; set; }

            //Kaynak, Hedef ve Agirlik özellikleri,
            //bir kenarın başlangıç düğümünü, bitiş düğümünü ve ağırlığını tutar.


            //CompareTo metodu, kenarları ağırlıklarına göre karşılaştırmak için kullanılır.

            // Kenarları ağırlıklarına göre karşılaştır
            public int CompareTo(Kenar diger)
             {
                  return this.Agirlik.CompareTo(diger.Agirlik);
             }
        }

        class Grafik
        {
            //Grafik sınıfı, bir grafı temsil eder.
             public int DugumSayisi { get; set; }
            //DugumSayisi özelliği, grafiğin düğüm sayısını tutar.
             public List<Kenar> Kenarlar { get; set; }
            //Kenarlar özelliği, grafiğin kenarlarını içeren bir Liste tutar.
            public Grafik(int dugumSayisi)
             {
                 DugumSayisi = dugumSayisi;
                 Kenarlar = new List<Kenar>();
             }
            //Grafik sınıfının yapıcı metodu, bir graf nesnesi oluştururken
            //düğüm sayısını alır ve kenar listesini başlatır.

            public void KenarEkle(int kaynak, int hedef, int agirlik)
             {
                //KenarEkle metodu, grafiğe yeni bir kenar ekler
                Kenarlar.Add(new Kenar { Kaynak = kaynak, Hedef = hedef, Agirlik = agirlik });
             }
            //Bu metot, başlangıç düğümünü, bitiş düğümünü ve kenarın ağırlığını alır
            //ve bu bilgilerle yeni bir Kenar nesnesi oluşturur.

            public int KökBul(int[] kök, int dugum)
            {
                //KökBul metodu, bir düğümün kökünü bulur
                if (kök[dugum] == dugum)
                     return dugum;
                return kök[dugum] = KökBul(kök, kök[dugum]);
            }

              public void Birleştir(int[] kök, int[] derece, int x, int y)
              {
                //Birleştir metodu, iki düğümün birleştirilmesini sağlar.
                int xKök = KökBul(kök, x);
                 int yKök = KökBul(kök, y);

                if (derece[xKök] < derece[yKök])
                   kök[xKök] = yKök;
                //eger xkok ykokten kucukse xkoku ykoke esitle 
                //tam tersi durumda  ykoku xkoke esitle
                else if (derece[xKök] > derece[yKök])
                   kök[yKök] = xKök;
                else
                {
                    //ykoku xkoke esitle ve derece koku arttır
                     kök[yKök] = xKök;
                     derece[xKök]++;
                }
              }   

              public void KruskalMST()
              {
                 //KruskalMST metodu, Kruskal algoritmasını uygular
                 //ve minimum gerilme ağacını hesaplar.
                 List<Kenar> sonuc = new List<Kenar>();
                 //sonuc listesi, minimum gerilme ağacına (MST) dahil edilecek kenarları tutar.
                 //Bir sonuç listesi oluşturur ve tüm kenarları ağırlıklarına göre sıralar.
                 int[] kök = new int[DugumSayisi];
                 //kok dizisi her dugumun kok dugumunu tutar
                 //Başlangıçta her düğüm kendi kökü olarak ayarlanır.
                 int[] derece = new int[DugumSayisi];
                 //derece dizisi, her düğümün ağaç derinliğini (rank) tutar.
                 //Başlangıçta tüm düğümlerin derinliği sıfırdır.


                //ASAGIDAKİ DONGU
                //Bu döngü, her düğümün başlangıçta kendi kökü olduğunu
                //ve derinliğinin sıfır olduğunu ayarlar.

                for (int i = 0; i < DugumSayisi; i++)
                {
                         kök[i] = i;
                         derece[i] = 0;
                }

                    Kenarlar.Sort();
                     //Kenarlar listesini,
                     //kenarların ağırlıklarına göre artan sırada sıralar

                foreach (var kenar in Kenarlar)
                {
                    //Bu döngü, her kenar için döner. KökBul metodu,
                    //her kenarın kaynak ve hedef düğümleri için kök düğümleri bulur.
                          int x = KökBul(kök, kenar.Kaynak);
                          int y = KökBul(kök, kenar.Hedef);

                          if (x != y)
                          {
                                 //Eğer iki düğümün kökleri farklı ise, bu kenar minimum gerilme ağacına dahil edilir (çünkü bu kenar, iki farklı ağacı birbirine bağlar ve bir döngü oluşturmaz).
                                  sonuc.Add(kenar);
                                 //Birleştir metodu, bu iki ağacı birleştirir, yani iki farklı kök düğümünü aynı kök altında birleştirir.
                                 //Bu işlem, ağacın kök ve derinlik bilgilerini günceller.
                                  Birleştir(kök, derece, x, y);
                          }
                }
                //Sonuç olarak, minimum gerilme ağacındaki kenarlar ve ağırlıkları yazdırılır.
                //Bu döngü, sonuc listesindeki her bir kenarı ekrana yazar
                Console.WriteLine("Kenar \tAğırlık");
                foreach (var kenar in sonuc)
                {
                         Console.WriteLine($"{kenar.Kaynak} - {kenar.Hedef}\t{kenar.Agirlik}");
                }
              }
        }


           

        internal static void KruskalCalistir()
        {
            int dugumSayisi = 4;
            Grafik grafik = new Grafik(dugumSayisi);

            grafik.KenarEkle(0, 1, 10);
            grafik.KenarEkle(0, 2, 6);
            grafik.KenarEkle(0, 3, 5);
            grafik.KenarEkle(1, 3, 15);
            grafik.KenarEkle(2, 3, 4);

            grafik.KruskalMST();
        }
    }

    }

